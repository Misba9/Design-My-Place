'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';

export function FloatingCTA() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show after scrolling past hero (approximately 100vh)
      const heroHeight = window.innerHeight;
      setIsVisible(window.scrollY > heroHeight * 0.5);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
          className="fixed bottom-6 right-6 z-40 lg:bottom-10 lg:right-10"
        >
          <Link
            href="#contact"
            className="group flex items-center gap-3 bg-charcoal-800/90 backdrop-blur-luxury border border-gold-500/40 px-5 py-3.5 hover:border-gold-400/60 transition-all duration-300"
          >
            <div className="w-2 h-2 rounded-full bg-gold-500 group-hover:scale-110 transition-transform duration-300" />
            <span className="label-uppercase text-ivory-100 text-[10px]">
              Book Free Consultation
            </span>
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
