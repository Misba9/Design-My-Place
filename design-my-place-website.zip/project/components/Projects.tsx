'use client';

import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';

const projects = [
  {
    id: 1,
    name: 'The Meridian Residence',
    location: 'Mumbai',
    type: 'Residential',
    style: 'Contemporary Minimal',
    year: '2024',
    area: '4,200 sq ft',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1600',
    size: 'large',
  },
  {
    id: 2,
    name: 'Azure Penthouse',
    location: 'Bangalore',
    type: 'Luxury Apartment',
    style: 'Japandi',
    year: '2024',
    area: '3,800 sq ft',
    image: 'https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800',
    size: 'small',
  },
  {
    id: 3,
    name: 'Verdant Villa',
    location: 'Pune',
    type: 'Villa',
    style: 'Modern Tropical',
    year: '2023',
    area: '6,500 sq ft',
    image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800',
    size: 'small',
  },
  {
    id: 4,
    name: 'The Canvas Office',
    location: 'Mumbai',
    type: 'Commercial',
    style: 'Industrial Chic',
    year: '2024',
    area: '8,000 sq ft',
    image: 'https://images.pexels.com/photos/32370580/pexels-photo-32370580.jpeg?auto=compress&cs=tinysrgb&w=1600',
    size: 'large',
  },
  {
    id: 5,
    name: 'Serenity Spa',
    location: 'Goa',
    type: 'Hospitality',
    style: 'Coastal Minimal',
    year: '2023',
    area: '5,200 sq ft',
    image: 'https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg?auto=compress&cs=tinysrgb&w=800',
    size: 'small',
  },
  {
    id: 6,
    name: 'Heritage Revival',
    location: 'Delhi',
    type: 'Renovation',
    style: 'Art Deco Modern',
    year: '2024',
    area: '4,800 sq ft',
    image: 'https://images.pexels.com/photos/2089698/pexels-photo-2089698.jpeg?auto=compress&cs=tinysrgb&w=800',
    size: 'small',
  },
];

function ProjectCard({
  project,
  index,
}: {
  project: (typeof projects)[0];
  index: number;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(cardRef, { once: true, margin: '-50px' });

  const isLarge = project.size === 'large';

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{
        duration: 0.8,
        delay: index * 0.1,
        ease: [0.25, 0.1, 0.25, 1],
      }}
      className={`group relative ${
        isLarge
          ? 'col-span-1 lg:col-span-2 row-span-2'
          : 'col-span-1'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`relative overflow-hidden ${
          isLarge ? 'aspect-[4/3] lg:aspect-[16/10]' : 'aspect-[4/5]'
        }`}
      >
        {/* Image */}
        <Image
          src={project.image}
          alt={project.name}
          fill
          className={`object-cover transition-transform duration-1000 ease-luxury ${
            isHovered ? 'scale-110' : 'scale-100'
          }`}
          sizes={isLarge ? '(max-width: 1024px) 100vw, 66vw' : '(max-width: 1024px) 50vw, 33vw'}
        />

        {/* Overlay */}
        <div
          className={`absolute inset-0 bg-charcoal-900/40 transition-opacity duration-500 ${
            isHovered ? 'opacity-100' : 'opacity-60'
          }`}
        />

        {/* Content */}
        <div className="absolute inset-0 p-6 lg:p-8 flex flex-col justify-end">
          {/* Metadata */}
          <div className="mb-4">
            <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.15em] text-ivory-400/70 mb-2">
              <span>{project.type}</span>
              <span className="w-1 h-1 rounded-full bg-gold-500/50" />
              <span>{project.style}</span>
              <span className="w-1 h-1 rounded-full bg-gold-500/50" />
              <span>{project.year}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-display text-2xl lg:text-3xl text-ivory-100 mb-2">
            {project.name}
          </h3>

          {/* Location & Area */}
          <p className="text-ivory-400/60 text-sm flex items-center gap-4 mb-4">
            <span>{project.location}</span>
            <span className="w-1 h-1 rounded-full bg-gold-500/30" />
            <span>{project.area}</span>
          </p>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={isHovered ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
            transition={{ duration: 0.3 }}
          >
            <button className="inline-flex items-center gap-2 text-gold-400 text-xs uppercase tracking-[0.15em] group/btn">
              <span className="relative">
                View Case Study
                <span className="absolute bottom-0 left-0 w-full h-px bg-gold-500/60 transition-all duration-300" />
              </span>
              <ArrowUpRight
                size={14}
                className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform duration-300"
              />
            </button>
          </motion.div>
        </div>

        {/* Border accent on hover */}
        <div
          className={`absolute inset-0 border border-gold-500/0 transition-all duration-500 pointer-events-none ${
            isHovered ? 'border-gold-500/20' : ''
          }`}
        />
      </div>
    </motion.div>
  );
}

export function Projects() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section
      id="projects"
      ref={containerRef}
      className="py-24 lg:py-40 bg-charcoal-800"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="mb-16 lg:mb-24 text-center lg:text-left">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="label-uppercase text-gold-400/70 mb-6"
          >
            Featured Work
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl md:text-5xl lg:text-6xl text-ivory-100"
          >
            Selected <span className="italic font-light">Projects</span>
          </motion.h2>
        </div>

        {/* Projects Grid - Masonry-style */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 auto-rows-auto">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 lg:mt-20 text-center"
        >
          <button className="btn-luxury">
            <span>View All Projects</span>
            <ArrowUpRight size={14} />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
