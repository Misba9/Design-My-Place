'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import Image from 'next/image';

const philosophyPoints = [
  {
    title: 'Research-Led',
    description: 'Every design decision stems from understanding how people interact with their environments.',
  },
  {
    title: 'Emotionally Connected',
    description: 'Spaces should evoke feeling. We design for how you want to live, not just how you want to look.',
  },
  {
    title: 'Timeless Aesthetics',
    description: 'We reject trends. Our interiors age gracefully, becoming more beautiful with time.',
  },
];

export function Story() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section id="studio" ref={containerRef} className="py-24 lg:py-40 bg-charcoal-900">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
            className="relative aspect-[4/5] lg:aspect-[3/4] overflow-hidden"
          >
            <div className="absolute inset-0 bg-charcoal-700">
              <Image
                src="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Interior architecture detail"
                fill
                className="object-cover opacity-80"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
              <div className="absolute inset-0 bg-charcoal-900/20" />
            </div>
            {/* Gold accent line */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={isInView ? { scaleX: 1 } : {}}
              transition={{ duration: 1.2, delay: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
              className="absolute bottom-0 left-0 right-0 h-px bg-gold-500/50 origin-left"
            />
          </motion.div>

          {/* Content Side */}
          <div className="flex flex-col justify-center">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="label-uppercase text-gold-400/70 mb-6"
            >
              Our Design Philosophy
            </motion.p>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="font-display text-4xl md:text-5xl lg:text-6xl text-ivory-100 mb-8 leading-[1.1]"
            >
              Spaces that hold <span className="italic font-light">your</span> story
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-ivory-300/70 text-lg lg:text-xl mb-10 leading-relaxed"
            >
              At Design My Place, we believe interiors are more than aesthetics.
              They are the backdrop to life&apos;s most meaningful moments.
              We create spaces that shape how people live, work, and feel.
            </motion.p>

            {/* Philosophy Points */}
            <div className="space-y-8">
              {philosophyPoints.map((point, index) => (
                <motion.div
                  key={point.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.5 + index * 0.15 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-8 h-8 border border-gold-500/30 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-gold-400/80 text-xs font-display">
                      0{index + 1}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-ivory-100 font-body mb-1">{point.title}</h3>
                    <p className="text-ivory-400/60 text-sm leading-relaxed">
                      {point.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
