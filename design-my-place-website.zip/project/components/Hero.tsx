'use client';

import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import Link from 'next/link';
import { ChevronDown, ArrowRight } from 'lucide-react';

export function Hero() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 1.05]);
  const y = useTransform(scrollYProgress, [0, 0.5], [0, 50]);

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Amber Glow Background */}
      <div className="absolute inset-0 bg-charcoal-900">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse 70% 50% at 50% 30%, rgba(184, 134, 11, 0.12) 0%, rgba(184, 134, 11, 0.06) 35%, transparent 70%)',
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 50% 100%, rgba(184, 134, 11, 0.05) 0%, transparent 50%)',
          }}
        />
      </div>

      {/* Architectural Line Motif */}
      <div className="absolute inset-0 pointer-events-none">
        <svg
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-[0.03]"
          viewBox="0 0 200 200"
          fill="none"
        >
          <path
            d="M100 20 C160 20, 180 80, 180 100"
            stroke="currentColor"
            strokeWidth="0.2"
            className="text-ivory-100"
          />
          <path
            d="M100 20 C40 20, 20 80, 20 100"
            stroke="currentColor"
            strokeWidth="0.2"
            className="text-ivory-100"
          />
        </svg>
      </div>

      {/* Floating Gold Accent Dot */}
      <motion.div
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.8, duration: 0.6 }}
        className="absolute top-1/3 left-1/4 w-1.5 h-1.5 rounded-full bg-gold-500/50"
      />

      {/* Content */}
      <motion.div
        style={{ opacity, scale, y }}
        className="relative z-10 max-w-6xl mx-auto px-6 lg:px-12 text-center"
      >
        {/* Kicker Line */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="label-uppercase text-gold-400/70 mb-8 lg:mb-10 flex items-center justify-center gap-4"
        >
          <span className="w-8 h-px bg-gold-500/30" />
          Luxury Interior Design Est. 2022
          <span className="w-8 h-px bg-gold-500/30" />
        </motion.p>

        {/* Main Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl text-ivory-100 mb-8 leading-[0.9] tracking-[-0.02em]"
        >
          Designing Meaningful
          <br />
          <span className="italic font-light">Spaces</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-ivory-300/70 text-lg md:text-xl lg:text-2xl max-w-2xl mx-auto mb-12 lg:mb-16 font-body font-light leading-relaxed"
        >
          We create interiors grounded in research, emotion, functionality, and
          timeless aesthetics.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-5 sm:gap-6"
        >
          <Link href="#contact" className="btn-luxury-primary group">
            <span>Book Design Consultation</span>
            <ArrowRight
              size={14}
              className="group-hover:translate-x-1 transition-transform duration-300"
            />
          </Link>
          <Link href="#projects" className="btn-luxury group">
            <span>Explore Projects</span>
            <ArrowRight
              size={14}
              className="group-hover:translate-x-1 transition-transform duration-300"
            />
          </Link>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 lg:bottom-12 right-8 lg:right-12 flex flex-col items-end gap-3"
      >
        <span className="label-uppercase text-ivory-400/50 text-[10px] rotate-90 origin-center translate-y-8">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown size={18} className="text-gold-500/50" />
        </motion.div>
      </motion.div>
    </section>
  );
}
