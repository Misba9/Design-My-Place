'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Instagram, Mail, MapPin, Phone, ArrowUpRight, Heart } from 'lucide-react';

const footerLinks = {
  explore: [
    { label: 'Projects', href: '#projects' },
    { label: 'Studio', href: '#studio' },
    { label: 'Services', href: '#services' },
    { label: 'Process', href: '#process' },
  ],
  connect: [
    { label: 'Consultation', href: '#contact' },
    { label: 'Instagram', href: 'https://instagram.com/design_my_place', external: true },
    { label: 'WhatsApp', href: 'https://wa.me/919876543210', external: true },
  ],
};

export function Footer() {
  const [email, setEmail] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Newsletter subscription logic
    console.log('Newsletter signup:', email);
    setEmail('');
  };

  return (
    <footer className="bg-charcoal-800 border-t border-ivory-200/5">
      {/* Newsletter Section */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          <div>
            <p className="label-uppercase text-gold-400/80 mb-4">Stay Inspired</p>
            <h3 className="font-display text-3xl lg:text-4xl text-ivory-100 mb-4">
              Receive design insights and inspiration
            </h3>
            <p className="text-ivory-400/60 text-body-lg max-w-md">
              Curated design stories, project reveals, and studio updates delivered to your inbox.
            </p>
          </div>

          <form onSubmit={handleNewsletterSubmit} className="flex flex-col justify-center">
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email for curated design stories"
                className="input-luxury pr-32"
                required
              />
              <button
                type="submit"
                className="absolute right-0 bottom-3 btn-luxury py-2 px-4 text-[10px]"
              >
                Subscribe
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-ivory-200/5" />

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link href="/" className="group flex items-center gap-3 mb-6">
              <div className="w-10 h-10 border border-gold-500/60 flex items-center justify-center">
                <span className="font-display text-gold-400 text-lg">D</span>
              </div>
              <span className="label-uppercase text-ivory-100">Design My Place</span>
            </Link>
            <p className="text-ivory-400/50 text-sm leading-relaxed mb-6">
              Creating interiors that shape how people live, work, and feel.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://instagram.com/design_my_place"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 border border-ivory-200/10 flex items-center justify-center text-ivory-400/60 hover:border-gold-500/50 hover:text-gold-400 transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href="mailto:hello@designmyplace.in"
                className="w-10 h-10 border border-ivory-200/10 flex items-center justify-center text-ivory-400/60 hover:border-gold-500/50 hover:text-gold-400 transition-all duration-300"
                aria-label="Email"
              >
                <Mail size={18} />
              </a>
              <a
                href="https://wa.me/919876543210"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 border border-ivory-200/10 flex items-center justify-center text-ivory-400/60 hover:border-gold-500/50 hover:text-gold-400 transition-all duration-300"
                aria-label="WhatsApp"
              >
                <Phone size={18} />
              </a>
            </div>
          </div>

          {/* Explore Column */}
          <div>
            <p className="label-uppercase text-ivory-300/60 mb-6">Explore</p>
            <ul className="space-y-4">
              {footerLinks.explore.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-ivory-400/70 hover:text-ivory-100 transition-colors duration-300 flex items-center gap-2 group"
                  >
                    <span className="w-0 group-hover:w-3 transition-all duration-300 overflow-hidden">
                      <ArrowUpRight size={14} className="text-gold-400" />
                    </span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect Column */}
          <div>
            <p className="label-uppercase text-ivory-300/60 mb-6">Connect</p>
            <ul className="space-y-4">
              {footerLinks.connect.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    target={link.external ? '_blank' : undefined}
                    rel={link.external ? 'noopener noreferrer' : undefined}
                    className="text-ivory-400/70 hover:text-ivory-100 transition-colors duration-300 flex items-center gap-2 group"
                  >
                    <span className="w-0 group-hover:w-3 transition-all duration-300 overflow-hidden">
                      <ArrowUpRight size={14} className="text-gold-400" />
                    </span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Location Column */}
          <div>
            <p className="label-uppercase text-ivory-300/60 mb-6">Studio Location</p>
            <div className="flex items-start gap-3 text-ivory-400/70 mb-4">
              <MapPin size={18} className="text-gold-500/50 flex-shrink-0 mt-1" />
              <p className="text-sm leading-relaxed">
                Design My Place LLP<br />
                Mumbai, Maharashtra<br />
                India
              </p>
            </div>
            <a
              href="mailto:hello@designmyplace.in"
              className="text-ivory-400/70 hover:text-ivory-100 transition-colors duration-300 text-sm flex items-center gap-2"
            >
              <Mail size={16} className="text-gold-500/50" />
              hello@designmyplace.in
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-ivory-200/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-ivory-400/40 text-xs">
            © {new Date().getFullYear()} Design My Place LLP. All rights reserved.
          </p>
          <p className="text-ivory-400/40 text-xs flex items-center gap-2">
            Crafted with <Heart size={12} className="text-gold-500/50" /> in India
          </p>
        </div>
      </div>
    </footer>
  );
}
