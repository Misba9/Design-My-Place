'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export function LeadGeneration() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section
      ref={containerRef}
      className="relative py-32 lg:py-48 overflow-hidden"
    >
      {/* Amber Glow Background */}
      <div className="absolute inset-0 bg-charcoal-900">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse 80% 60% at 50% 30%, rgba(184, 134, 11, 0.15) 0%, rgba(184, 134, 11, 0.06) 40%, transparent 70%)',
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 30% 70%, rgba(184, 134, 11, 0.08) 0%, transparent 40%)',
          }}
        />
      </div>

      {/* Decorative line */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={isInView ? { scaleX: 1 } : {}}
        transition={{ duration: 1.5, ease: [0.25, 0.1, 0.25, 1] }}
        className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent"
      />

      <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-12 text-center">
        {/* Headline */}
        <motion.h2
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.2 }}
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl text-ivory-100 mb-8 leading-[0.95]"
        >
          Your home is waiting
          <br />
          to tell its <span className="italic font-light">story</span>
        </motion.h2>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-ivory-300/60 text-lg md:text-xl lg:text-2xl max-w-2xl mx-auto mb-12 leading-relaxed"
        >
          Let&apos;s design something remarkable together. Tell us about your space,
          and we&apos;ll help transform it into something extraordinary.
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <Link
            href="#contact"
            className="group inline-flex items-center gap-4 px-8 py-5 border border-gold-500/50 text-ivory-100 uppercase tracking-[0.15em] text-xs font-body transition-all duration-500 hover:border-gold-400/70"
          >
            <span>Start Your Design Journey</span>
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform duration-300"
            />
          </Link>
        </motion.div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16 flex flex-wrap justify-center items-center gap-8 lg:gap-12"
        >
          <div className="flex items-center gap-2 text-ivory-400/40 text-sm">
            <div className="w-1.5 h-1.5 rounded-full bg-gold-500/40" />
            <span>75+ Projects</span>
          </div>
          <div className="flex items-center gap-2 text-ivory-400/40 text-sm">
            <div className="w-1.5 h-1.5 rounded-full bg-gold-500/40" />
            <span>Free Consultation</span>
          </div>
          <div className="flex items-center gap-2 text-ivory-400/40 text-sm">
            <div className="w-1.5 h-1.5 rounded-full bg-gold-500/40" />
            <span>All Across India</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
