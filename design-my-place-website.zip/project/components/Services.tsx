'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Home, Building2, Warehouse, Briefcase, Palette, Sofa } from 'lucide-react';

const services = [
  {
    icon: Home,
    title: 'Residential Interiors',
    description: 'Complete home transformations that reflect your lifestyle and aspirations.',
  },
  {
    icon: Building2,
    title: 'Luxury Apartments',
    description: 'Sophisticated urban living spaces designed for modern life.',
  },
  {
    icon: Warehouse,
    title: 'Villa Design',
    description: 'Expansive residences crafted with architectural sensitivity.',
  },
  {
    icon: Briefcase,
    title: 'Commercial Interiors',
    description: 'Workspaces that inspire productivity and reflect brand identity.',
  },
  {
    icon: Palette,
    title: 'Workspace Design',
    description: 'Offices and studios designed for creativity and collaboration.',
  },
  {
    icon: Sofa,
    title: 'Renovation & Styling',
    description: 'Breathing new life into existing spaces with refined touches.',
  },
];

export function Services() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section
      id="services"
      ref={containerRef}
      className="py-24 lg:py-40 bg-ivory-200 text-charcoal-800"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="mb-16 lg:mb-24 text-center lg:text-left">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="label-uppercase text-gold-600/70 mb-6"
          >
            Our Expertise
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl md:text-5xl lg:text-6xl"
          >
            Design <span className="italic font-light">Services</span>
          </motion.h2>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: 0.2 + index * 0.1,
              }}
              className="group relative p-8 lg:p-10 bg-ivory-100 border border-charcoal-800/5 transition-all duration-500 hover:border-gold-500/30 hover:bg-ivory-50"
            >
              {/* Number indicator */}
              <span className="absolute top-8 right-8 text-charcoal-800/10 text-5xl font-display group-hover:text-gold-500/20 transition-colors duration-500">
                0{index + 1}
              </span>

              {/* Icon */}
              <div className="w-12 h-12 border border-charcoal-800/20 flex items-center justify-center mb-6 group-hover:border-gold-500/50 transition-colors duration-500">
                <service.icon
                  size={22}
                  className="text-charcoal-800/60 group-hover:text-gold-600 transition-colors duration-500"
                />
              </div>

              {/* Content */}
              <h3 className="font-display text-xl text-charcoal-800 mb-3">
                {service.title}
              </h3>
              <p className="text-charcoal-600/60 text-sm leading-relaxed">
                {service.description}
              </p>

              {/* Hover line */}
              <div className="absolute bottom-0 left-0 w-0 h-px bg-gold-500/40 transition-all duration-500 group-hover:w-full" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
