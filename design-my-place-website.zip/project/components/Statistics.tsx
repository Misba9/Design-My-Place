'use client';

import { motion, useInView, useSpring } from 'framer-motion';
import { useRef, useEffect, useState } from 'react';

const stats = [
  { label: 'Projects Completed', value: 75, suffix: '+' },
  { label: 'Years of Experience', value: 3, suffix: '+' },
  { label: 'Happy Clients', value: 150, suffix: '+' },
  { label: 'Design Consultations', value: 500, suffix: '+' },
];

function AnimatedNumber({ value, suffix }: { value: number; suffix: string }) {
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  useEffect(() => {
    if (!isInView) return;

    const duration = 2000;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing function for smooth animation
      const eased = 1 - Math.pow(1 - progress, 4);
      const current = Math.floor(eased * value);

      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isInView, value]);

  return (
    <span ref={ref} className="font-display text-5xl lg:text-6xl xl:text-7xl text-ivory-100">
      {displayValue}
      <span className="text-gold-400">{suffix}</span>
    </span>
  );
}

export function Statistics() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section
      ref={containerRef}
      className="py-24 lg:py-40 bg-charcoal-900 relative overflow-hidden"
    >
      {/* Subtle glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 60% 30% at 25% 50%, rgba(184, 134, 11, 0.05) 0%, transparent 60%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: index * 0.1,
              }}
              className="text-center lg:text-left"
            >
              <AnimatedNumber value={stat.value} suffix={stat.suffix} />
              <p className="label-uppercase text-ivory-400/60 mt-4">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
